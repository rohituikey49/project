# Firebase Quickstarts for Node.js

A collection of quickstart samples demonstrating the Firebase APIs using the Node.js Admin SDK. For more information, see https://firebase.google.com.

## How to make contributions?
Please read and follow the steps in the [CONTRIBUTING.md](CONTRIBUTING.md)

## License
See [LICENSE](LICENSE)
